package com.transaction.account.transactions.accountTransactionsEureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class AccountTransactionsEurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountTransactionsEurekaApplication.class, args);
	}

}
