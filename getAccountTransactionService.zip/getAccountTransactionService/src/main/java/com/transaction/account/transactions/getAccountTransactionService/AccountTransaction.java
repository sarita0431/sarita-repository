package com.transaction.account.transactions.getAccountTransactionService;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class AccountTransaction {

	@Id
	private String transactionId;

	private Integer accountNumber;

	@Temporal(TemporalType.TIMESTAMP)
	private Date transactionDate;

	private BigDecimal balance;

	@Column(name = "TRANSACTION_TYPE")
	private String transactionType;

	public AccountTransaction(String transactionId, Integer accountNumber, Date transactionDate, BigDecimal balance,
			String transactionType) {
		super();
		this.transactionId = transactionId;
		this.accountNumber = accountNumber;
		this.transactionDate = transactionDate;
		this.balance = balance;
		this.transactionType = transactionType;
	}

	public AccountTransaction() {
		super();
	}

	public Integer getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

}
