package com.transaction.account.transactions.getAccountTransactionService;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.transaction.account.transactions.getAccountTransactionService.exception.TransactionsNotFoundException;

@RestController
public class AccountTransactionController {

	@Autowired
	private AccountTransactionService service;

	@GetMapping("/accountTransactions/{accountNumber}/{startDate}/{endDate}")
	public List<AccountTransaction> getAccountTransaction(@PathVariable String accountNumber,
			@PathVariable String startDate, @PathVariable String endDate) {

		Date startDateInDateFormat = convertStringToDateFormat(startDate);
		Date endDateInDateFormat = convertStringToDateFormat(endDate);
		Integer accNumber = Integer.parseInt(accountNumber);

		List<AccountTransaction> accountTransactionList = service.getAccountTransactions(accNumber,
				startDateInDateFormat, endDateInDateFormat);

		if (accountTransactionList.isEmpty()) {
			throw new TransactionsNotFoundException(
					"No Records Found for " + accountNumber + " for time range " + startDate + " to " + endDate);
		}
		return accountTransactionList;

	}

	@GetMapping("/accountTransactionsType/{transactionType}/{startDate}/{endDate}")
	public List<AccountTransaction> getAccountTransactionsForType(@PathVariable String transactionType,
			@PathVariable String startDate, @PathVariable String endDate) {

		Date startDateInDateFormat = convertStringToDateFormat(startDate);
		Date endDateInDateFormat = convertStringToDateFormat(endDate);

		List<AccountTransaction> accountTransactionList = service.getAccountTransactionsForType(transactionType,
				startDateInDateFormat, endDateInDateFormat);

		if (accountTransactionList.isEmpty()) {
			throw new TransactionsNotFoundException(
					"No Records Found for " + transactionType + " for time range " + startDate + " to " + endDate);
		}

		return accountTransactionList;

	}

	@GetMapping("/accountTransactionsForSpecificDay/{accountNumber}/{specificDay}")
	public List<AccountTransaction> getAccountTransactionsForSpecificDay(@PathVariable Integer accountNumber,
			@PathVariable String specificDay) throws ParseException {

		List<AccountTransaction> accountTransactionList = null;

		switch (specificDay) {
		case "Today":
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date dateWithoutTime = sdf.parse(sdf.format(new Date()));

			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.HOUR_OF_DAY, 11);
			cal.set(Calendar.MINUTE, 59);
			cal.set(Calendar.SECOND, 59);
			cal.set(Calendar.MILLISECOND, 59);
			Date dateWitEndTime = cal.getTime();

			accountTransactionList = service.getAccountTransactions(accountNumber, dateWithoutTime, dateWitEndTime);
			if (accountTransactionList.isEmpty())
				throw new TransactionsNotFoundException("No Records Found for " + accountNumber + " for today");
			break;

		case "Last 7 Days":

			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_MONTH, -7);
			Date sevenDaysBefore = calendar.getTime();
			accountTransactionList = service.getAccountTransactions(accountNumber, sevenDaysBefore,
					Calendar.getInstance().getTime());
			if (accountTransactionList.isEmpty())
				throw new TransactionsNotFoundException("No Records Found for " + accountNumber + " for Last 7 days");
			break;
		case "Last Month":

			Calendar calendarEndDate = Calendar.getInstance();
			calendarEndDate.add(Calendar.MONTH, -1);

			int max = calendarEndDate.getActualMaximum(Calendar.DAY_OF_MONTH);
			calendarEndDate.set(Calendar.DAY_OF_MONTH, max);

			Calendar calendarStartDate = Calendar.getInstance();
			calendarStartDate.add(Calendar.MONTH, -1);

			int min = calendarStartDate.getActualMinimum(Calendar.DAY_OF_MONTH);
			calendarStartDate.set(Calendar.DAY_OF_MONTH, min);

			accountTransactionList = service.getAccountTransactions(accountNumber, calendarStartDate.getTime(),
					calendarEndDate.getTime());

			if (accountTransactionList.isEmpty())
				throw new TransactionsNotFoundException("No Records Found for " + accountNumber + " for last month");
			
			break;
		}
		return accountTransactionList;

	}

	@GetMapping("latestAccountDetails/{accountNumber}")
	public AccountTransaction getLatestAccountDetails(@PathVariable String accountNumber) {
		Integer accNumber = Integer.parseInt(accountNumber);
		AccountTransaction accountTransaction =  service.getLatestTransactionForAccount(accNumber);
		if(accountTransaction == null)
			throw new TransactionsNotFoundException("No Latest Records Found for " + accountNumber );
		else
			return accountTransaction;
	}

	private Date convertStringToDateFormat(String dateInString) {
		SimpleDateFormat formatter = new SimpleDateFormat("MMMM dd, yyyy");

		Date date = null;
		try {
			date = formatter.parse(dateInString);
			DateFormat destDf = new SimpleDateFormat("yyyy-MM-dd");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

}
