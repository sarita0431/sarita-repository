package com.transaction.account.transactions.getAccountTransactionService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetAccountTransactionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetAccountTransactionServiceApplication.class, args);
	}

}
