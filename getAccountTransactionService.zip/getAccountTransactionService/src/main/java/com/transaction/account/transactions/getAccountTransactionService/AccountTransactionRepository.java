package com.transaction.account.transactions.getAccountTransactionService;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AccountTransactionRepository extends JpaRepository<AccountTransaction, Integer> {

	@Query(value = "from AccountTransaction t where accountNumber= :accNum AND transactionDate BETWEEN :startDate AND :endDate")
	public List<AccountTransaction> getAllBetweenDates(@Param("accNum") Integer accNum,
			@Param("startDate") Date startDate, @Param("endDate") Date endDate);

	@Query(value = "from AccountTransaction t where transactionType= :transactionType AND transactionDate BETWEEN :startDate AND :endDate")
	public List<AccountTransaction> getAllByTransactionType(@Param("transactionType") String transactionType,
			@Param("startDate") Date startDate, @Param("endDate") Date endDate);

	@Query(value="from AccountTransaction at1 where transactionDate = (Select MAX(transactionDate) from AccountTransaction  where accountNumber = :accountNumber)")
	public AccountTransaction getLatestTransactionForAccount(@Param("accountNumber") Integer accountNumber);
}
