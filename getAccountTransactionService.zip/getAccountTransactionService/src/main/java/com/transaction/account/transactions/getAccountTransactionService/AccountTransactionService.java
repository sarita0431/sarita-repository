package com.transaction.account.transactions.getAccountTransactionService;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountTransactionService {

	@Autowired
	private AccountTransactionRepository repository;

	public List<AccountTransaction> getAccountTransactions(Integer accNum, Date startDate, Date endDate) {

		return repository.getAllBetweenDates(accNum, startDate, endDate);
	}

	public List<AccountTransaction> getAccountTransactionsForType(String transactionType, Date startDate,
			Date endDate) {
		return repository.getAllByTransactionType(transactionType, startDate, endDate);
	}

	public AccountTransaction getLatestTransactionForAccount(Integer accountNumber) {
		return repository.getLatestTransactionForAccount(accountNumber);
		
	}

	
}
