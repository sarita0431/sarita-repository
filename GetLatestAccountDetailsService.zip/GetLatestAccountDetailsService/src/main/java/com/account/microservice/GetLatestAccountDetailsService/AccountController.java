package com.account.microservice.GetLatestAccountDetailsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.account.microservice.GetLatestAccountDetailsService.exception.AccountDetailsNotFoundException;


@RestController
public class AccountController {

	@Autowired
	private AccountTransactionProxy proxy;
	
	
	@GetMapping("/getAccountDetails/{accountNumber}")
	public Account getAccountLatestDetails(@PathVariable String accountNumber) {

		Account account = proxy.retrieveLatestTransactionForAccount(accountNumber);
		if (account == null)
			throw new AccountDetailsNotFoundException("No Latest Records Found For " + accountNumber);
		else
			return account;
	}
	
	
}
