package com.account.microservice.GetLatestAccountDetailsService;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Account {

	@Id
	private Integer accountNumber;
	private Date transactionDate;
	private BigDecimal balance;

	public Integer getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public Account() {
		super();
	}

	public Account(Integer accountNumber, Date transactionDate, BigDecimal balance) {
		super();
		this.accountNumber = accountNumber;
		this.transactionDate = transactionDate;
		this.balance = balance;
	}

}
