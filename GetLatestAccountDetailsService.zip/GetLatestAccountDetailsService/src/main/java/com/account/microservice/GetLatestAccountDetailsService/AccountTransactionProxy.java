package com.account.microservice.GetLatestAccountDetailsService;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.account.microservice.GetLatestAccountDetailsService.exception.AccountDetailsNotFoundException;

@FeignClient(name = "account-transaction",fallbackFactory=AccountDetailsNotFoundException.class)
public interface AccountTransactionProxy {

	@GetMapping("/latestAccountDetails/{accountNumber}")
	public Account retrieveLatestTransactionForAccount(@PathVariable("accountNumber")
	String accountNumber);

}
